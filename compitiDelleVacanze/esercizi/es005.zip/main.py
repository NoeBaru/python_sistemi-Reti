from machine import Pin, ADC, PWM

potenziometer = ADC(27) #dichiarazione del pin del potenziometro

led = PWM(Pin(21, Pin.OUT)) #dichiarazione del pin del led

led.freq(500) #frequenza del led
led.duty_u16(0); #spegnimento led

while True: #ciclo infinito

  value = potenziometer.read_u16(); #lettura valore del potenziometro

  print(value / 65535) #per testare

  led.duty_u16(value)