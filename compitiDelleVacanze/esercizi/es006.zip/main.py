from machine import Pin, ADC, PWM

potenziometer = ADC(27) #dichiarazione del pin del potenziometro

ledsPins[11,12,13,14,15,16] #dichiarazione del pin del led
led.freq(500) #frequenza del led
led.duty_u16(0); #spegnimento led

cont = 0

leds = [machine.Pin(pin, machine.Pin.OUT) for pin in ledPins] # Inizializza i pin dei LED come pin di output

while True: #ciclo infinito
  value = potenziometer.read_u16(); #lettura valore del potenziometro

  if(value > 0)
    cont += 1
    leds.duty_u16(value)
    leds[cont].value(1)
    utime.sleep_ms(0.2)
    print(value / 65535) #per testare