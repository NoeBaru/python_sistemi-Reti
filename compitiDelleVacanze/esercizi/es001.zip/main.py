from machine import Pin
import utime

#obiettivo: accendere il led integrato del Raspberry Pi Pico

ledBuiltIn = Pin(25, Pin.OUT) #inizializzazione led interno

while True:
  ledBuiltIn.value(1) #led integrato acceso

  utime.sleep(2) #tempo di attesa di due secondi

  ledBuiltIn.value(0) #led integrato spento

  utime.sleep(2) #tempo di attesa di due secondi