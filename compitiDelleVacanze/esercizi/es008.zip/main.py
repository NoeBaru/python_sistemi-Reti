from machine import ADC #per leggere gli ingressi analogici
from utime import sleep

sensor = ADC(4) #sensore di temperatura nell'ingresso pin 4

while True:
  voltage = sensor.read_u16() * 3.3 / 65535
  #per converitre in volt, 3,3 v massima tensione del Pico e i valori letti dall' ingresso analogico arrivano fino a 65535
  temperature = 27 - (voltage - 0.706) / 0.001721 #formula del datasheet del microcontrollore per ottenere i gradi celsius
  print(temperature) #stampa la temperatura
  sleep(1) #1 sec di ritardo