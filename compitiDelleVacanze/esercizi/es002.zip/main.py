from machine import Pin, PWM
import time

pwm = PWM(Pin(16))
pwm.freq(1000) #1khz

while True: #ciclo infinito
  for duty in range(0, 65025, 7): #da spento ad acceso
    pwm.duty_u16(duty)
    time.sleep(0.0001) #attesa di 1 sec
  for duty in range(65025, 0, -7): #da acceso a spento
    pwm.duty_u16(duty)
    time.sleep(0.0001) #attesa di 1 sec
