from machine import Pin
import time

buttonE = Pin(18, Pin.IN, Pin.PULL_UP)
buttonP = Pin(22, Pin.IN, Pin.PULL_UP) #dichiarazione pulsante
ledV = Pin(1, Pin.OUT) #dichiarazione led1
ledG = Pin(5, Pin.OUT) #dichiarazione led2
ledR = Pin(9, Pin.OUT) #dichiarazione led3

k = 0
c = 0
man = false
ped = false

while True: #ciclo infinito
  if (buttonP.value(1))
    ped = true
    
  if(buttonE.value(1))
    k += 1
    
    if (k == 1)
      man = true;
      c = 1

    if (k == 2)   
      man = false
      k = 0
      c = 0

  if(man == true)
    if(c == 1)
      ledv.value(0) #led verde si spegne
      ledr.value(0) #led rosso si spegne
      ledg.value(1) #led giallo si accende
      time.sleep(0.4) #secondi

      ledg.value(0) #led giallo si spegne
      ledr.value(1) #led rosso si accende
      time.sleep(0.4) #secondi
      c += 1

    if(c == 2)
      ledv.value(0) #led verde si spegne
      ledr.value(0) #led rosso si spegne
      ledg.value(1) #led giallo si accende
      time.sleep(0.4) #secondi
      ledg.value(0) #led giallo si spegne

  else if(ped == true)
    ledr.value(0) #led rosso si spegne
    ledv.value(1) #led verde si accende
    time.sleep(0.4) #secondi
    ledv.value(0) #led verde si spegne

    ledg.value(1) #led giallo si accende
    time.sleep(0.4) #secondi
    ledg.value(0) #led giallo si spegne

    ped = false
    time.sleep(0.4) #secondi
  else
    ledr.value(1) #led rosso si accende
    time.sleep(0.4) #secondi
    ledr.value(0) #led rosso si spegne
    