from machine import Pin
import time

button = Pin(28, Pin.IN, Pin.PULL_UP) #dichiarazione pulsante
led1 = Pin(1, Pin.OUT) #dichiarazione led1
led2 = Pin(5, Pin.OUT) #dichiarazione led2
led3 = Pin(9, Pin.OUT) #dichiarazione led3

k = 0

while True: #ciclo infinito
  if button.value():
    k += 1
  if(k == 0)
    led1.value(1) #led si accende
    time.sleep(0.2) #secondi
    led1.value(0) #led si spegne

  if(k == 1)
    led2.value(1) #led si accende
    time.sleep(0.2) #secondi
    led2.value(0) #led si spegne

  if(k == 2)
    led3.value(1) #led si accende
    time.sleep(0.2) #secondi
    led3.value(0) #led si spegne
    k = 0