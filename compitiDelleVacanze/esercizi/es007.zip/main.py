from machine import ADC
from machine import Pin
import utime

fotoresPin = ADC(26) #pin analogico per il fotoresistore

ledPin = Pin(5, machine.Pin.OUT) #pin del LED

freq = TENS / (1 <<12) #valore fotoresistore

while True:

    valoreF = fotoresPin.read_u16()

    if valoreF < freq:
        ledPin.value(1)  # Accendi il LED
    else:
        ledPin.value(0)  # Spegni il LED

    utime.sleep(1) # Attende prima di leggere di nuovo il fotoresistore